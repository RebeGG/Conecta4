package conecta4_cliente.Controlador;


//  Universidad Nacional
//  Facultad de Ciencias Exactas y Naturales
//  Escuela de Informática
//  
//     Práctica #5
//    (Controlador)
//
//  Autores: Rebecca Garita Gutiérrez
//           María Fernanda González Arias
//
//  III Ciclo 2019

public class Controlador {
//    private Cliente cliente;
//    
//    public Controlador(){
//        cliente = new Cliente();
//    }
//    
//    public void enviarTurno(int x, int y){
//        cliente.enviarTurno(x, y);
//    }
//    
//    public void actualizar(){
//        cliente.update();
//    }
//    
//    public void registrar(Observer obs) {
//        cliente.addObserver(obs);
//    }
}
